--------------------------------------------

Author : Siddharth Nahar
Entry No : 2016csb1043
Use : Basic Python coding,with Beautiful soup library
      and Basic File Handling
Date : 2/4/18

--------------------------------------------

For Compilation and Run:

User:\Path_DIR$ python CSL202_2016csb1043_5.py HTML_FILE_PATH

Output : 

* DileName.dedup file will be created

--------------------------------------------

Working : 

* Reads the file and Stores a links according to line_numbers.

* Finding duplicates in links and Printing it to output.

* Remove links according to coice of user.
